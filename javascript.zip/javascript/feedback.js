function selectstar1(clicked_id) {


    if (clicked_id == "reach1") {
        var element = document.getElementById("reach1");
        var element2 = document.getElementById("reach2");
        var element3 = document.getElementById("reach3");
        var element4 = document.getElementById("reach4");
        var element5 = document.getElementById("reach5");
        element.classList.add("checked");
        element2.classList.remove("checked");
        element3.classList.remove("checked");
        element4.classList.remove("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "reach2") {
        var element = document.getElementById("reach1");
        var element2 = document.getElementById("reach2");
        var element3 = document.getElementById("reach3");
        var element4 = document.getElementById("reach4");
        var element5 = document.getElementById("reach5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.remove("checked");
        element4.classList.remove("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "reach3") {
        var element = document.getElementById("reach1");
        var element2 = document.getElementById("reach2");
        var element3 = document.getElementById("reach3");
        var element4 = document.getElementById("reach4");
        var element5 = document.getElementById("reach5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.add("checked");
        element4.classList.remove("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "reach4") {
        var element = document.getElementById("reach1");
        var element2 = document.getElementById("reach2");
        var element3 = document.getElementById("reach3");
        var element4 = document.getElementById("reach4");
        var element5 = document.getElementById("reach5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.add("checked");
        element4.classList.add("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "reach5") {
        var element = document.getElementById("reach1");
        var element2 = document.getElementById("reach2");
        var element3 = document.getElementById("reach3");
        var element4 = document.getElementById("reach4");
        var element5 = document.getElementById("reach5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.add("checked");
        element4.classList.add("checked");
        element5.classList.add("checked");
    }

}

function selectstar2(clicked_id) {


    if (clicked_id == "loc1") {
        var element = document.getElementById("loc1");
        var element2 = document.getElementById("loc2");
        var element3 = document.getElementById("loc3");
        var element4 = document.getElementById("loc4");
        var element5 = document.getElementById("loc5");
        element.classList.add("checked");
        element2.classList.remove("checked");
        element3.classList.remove("checked");
        element4.classList.remove("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "loc2") {
        var element = document.getElementById("loc1");
        var element2 = document.getElementById("loc2");
        var element3 = document.getElementById("loc3");
        var element4 = document.getElementById("loc4");
        var element5 = document.getElementById("loc5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.remove("checked");
        element4.classList.remove("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "loc3") {
        var element = document.getElementById("loc1");
        var element2 = document.getElementById("loc2");
        var element3 = document.getElementById("loc3");
        var element4 = document.getElementById("loc4");
        var element5 = document.getElementById("loc5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.add("checked");
        element4.classList.remove("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "loc4") {
        var element = document.getElementById("loc1");
        var element2 = document.getElementById("loc2");
        var element3 = document.getElementById("loc3");
        var element4 = document.getElementById("loc4");
        var element5 = document.getElementById("loc5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.add("checked");
        element4.classList.add("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "loc5") {
        var element = document.getElementById("loc1");
        var element2 = document.getElementById("loc2");
        var element3 = document.getElementById("loc3");
        var element4 = document.getElementById("loc4");
        var element5 = document.getElementById("loc5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.add("checked");
        element4.classList.add("checked");
        element5.classList.add("checked");
    }







}


function selectstar3(clicked_id) {


    if (clicked_id == "share1") {
        var element = document.getElementById("share1");
        var element2 = document.getElementById("share2");
        var element3 = document.getElementById("share3");
        var element4 = document.getElementById("share4");
        var element5 = document.getElementById("share5");
        element.classList.add("checked");
        element2.classList.remove("checked");
        element3.classList.remove("checked");
        element4.classList.remove("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "share2") {
        var element = document.getElementById("share1");
        var element2 = document.getElementById("share2");
        var element3 = document.getElementById("share3");
        var element4 = document.getElementById("share4");
        var element5 = document.getElementById("share5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.remove("checked");
        element4.classList.remove("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "share3") {
        var element = document.getElementById("share1");
        var element2 = document.getElementById("share2");
        var element3 = document.getElementById("share3");
        var element4 = document.getElementById("share4");
        var element5 = document.getElementById("share5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.add("checked");
        element4.classList.remove("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "share4") {
        var element = document.getElementById("share1");
        var element2 = document.getElementById("share2");
        var element3 = document.getElementById("share3");
        var element4 = document.getElementById("share4");
        var element5 = document.getElementById("share5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.add("checked");
        element4.classList.add("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "share5") {
        var element = document.getElementById("share1");
        var element2 = document.getElementById("share2");
        var element3 = document.getElementById("share3");
        var element4 = document.getElementById("share4");
        var element5 = document.getElementById("share5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.add("checked");
        element4.classList.add("checked");
        element5.classList.add("checked");
    }







}



function selectstar4(clicked_id) {


    if (clicked_id == "transit1") {
        var element = document.getElementById("transit1");
        var element2 = document.getElementById("transit2");
        var element3 = document.getElementById("transit3");
        var element4 = document.getElementById("transit4");
        var element5 = document.getElementById("transit5");
        element.classList.add("checked");
        element2.classList.remove("checked");
        element3.classList.remove("checked");
        element4.classList.remove("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "transit2") {
        var element = document.getElementById("transit1");
        var element2 = document.getElementById("transit2");
        var element3 = document.getElementById("transit3");
        var element4 = document.getElementById("transit4");
        var element5 = document.getElementById("transit5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.remove("checked");
        element4.classList.remove("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "transit3") {
        var element = document.getElementById("transit1");
        var element2 = document.getElementById("transit2");
        var element3 = document.getElementById("transit3");
        var element4 = document.getElementById("transit4");
        var element5 = document.getElementById("transit5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.add("checked");
        element4.classList.remove("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "transit4") {
        var element = document.getElementById("transit1");
        var element2 = document.getElementById("transit2");
        var element3 = document.getElementById("transit3");
        var element4 = document.getElementById("transit4");
        var element5 = document.getElementById("transit5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.add("checked");
        element4.classList.add("checked");
        element5.classList.remove("checked");
    } else if (clicked_id == "transit5") {
        var element = document.getElementById("transit1");
        var element2 = document.getElementById("transit2");
        var element3 = document.getElementById("transit3");
        var element4 = document.getElementById("transit4");
        var element5 = document.getElementById("transit5");
        element.classList.add("checked");
        element2.classList.add("checked");
        element3.classList.add("checked");
        element4.classList.add("checked");
        element5.classList.add("checked");
    }
}

function validateEmail() {
  var email = document.getElementById("email_id").value;
    var regexemail = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    var emailresult = regexemail.test(email);

    if (emailresult == true) {
      alert("your feedback has been submitted successfully");
    } else {
        alert("Invalid email id")
    }

}

var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
 // var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";  
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}    
  //for (i = 0; i < dots.length; i++) 
   // dots[i].className = dots[i].className.replace(" active", "");

  slides[slideIndex-1].style.display = "block";  
 // dots[slideIndex-1].className += " active";
  setTimeout(showSlides, 2000); // Change image every 2 seconds
}
